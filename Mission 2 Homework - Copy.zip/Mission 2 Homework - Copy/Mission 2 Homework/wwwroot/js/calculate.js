﻿//document.getElementById("buttonsend").addEventListener("click", function() {
$('#calculate').click(function () {
    
    let score = ($("#assignments").val()*.55) + ($("#groupProjects").val()*.05) + ($("#quizzes").val()*.1) + ($("#exams").val()*.2) + ($("#intex").val()*.1)
    if (score >= 94)
        totalScore = 'A'
    else if (score >= 90)
        totalScore = 'A-'
    else if (score >= 87)
        totalScore = 'B+'
    else if (score >= 84)
        totalScore = 'B'
    else if (score >= 80)
        totalScore = 'B-'
    else if (score >= 77)
        totalScore = 'C+'
    else if (score >= 74)
        totalScore = 'C'
    else if (score >= 70)
        totalScore = 'C-'
    else if (score >= 67)
        totalScore = 'D+'
    else if (score >= 64)
        totalScore = 'D'
    else if (score >= 60)
        totalScore = 'D-'
    else
        totalScore ='F'

    alert(
        "Assignment: " + $("#assignments").val() + "%" +
        "\n" + "Group Projects: " + $("#groupProjects").val() + "%" +
        "\n" + "Quizzes: " + $("#quizzes").val() + "%" +
        "\n" + "Exams: " + $("#exams").val() + "%" +
        "\n" + "Intex: " + $("#intex").val() + "%" +
        "\n" + "Final Grade: " + score+ "%    " + totalScore
    )

}) 